package com.example.practicavidas

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import com.example.practicavidas.databinding.FragmentFirstBinding
import com.google.android.material.snackbar.Snackbar

class FirstFragment : Fragment() {
    
    private var _binding: FragmentFirstBinding? = null
    private val binding get() = _binding!!
    
    // Dades dels 2 jugadors
    private var life1: Int = 20
    private var life2: Int = 20
    
    private var poison1: Int = 0
    private var poison2: Int = 0
    
    // Generador de so
    private val toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (savedInstanceState != null) {
            life1 = savedInstanceState.getInt("life1")
            life2 = savedInstanceState.getInt("life2")
            
            poison1 = savedInstanceState.getInt("poison1")
            poison2 = savedInstanceState.getInt("poison2")
        }
        
        setupEventListenersUnified()
        updateViews()
        setupMenu()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun playClickSound() {
        toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
    }

    private fun setupEventListenersUnified() {
        val clickListener = View.OnClickListener { view ->
            playClickSound()
            when (view.id) {
                // Player 1
                R.id.p1_life_more -> incLife1()
                R.id.p1_life_less -> decLife1()
                R.id.p1_poison_more -> incPoison1()
                R.id.p1_poison_less -> decPoison1()
                
                // Player 2
                R.id.p2_life_more -> incLife2()
                R.id.p2_life_less -> decLife2()
                R.id.p2_poison_more -> incPoison2()
                R.id.p2_poison_less -> decPoison2()

                // Transfer buttons
                R.id.btn_transfer_up -> { decLife1(); incLife2() }
                R.id.btn_transfer_down -> { decLife2(); incLife1() }
            }
        }
        
        with(binding) {
            listOf(
                p1LifeMore, p1LifeLess, p1PoisonMore, p1PoisonLess,
                p2LifeMore, p2LifeLess, p2PoisonMore, p2PoisonLess,
                btnTransferUp, btnTransferDown
            ).forEach { button ->
                button.setOnClickListener(clickListener)
            }
        }
    }

    // Player 1 operations
    private fun incLife1() { life1++; updateViews() }
    private fun decLife1() { if (life1 > 0) life1--; updateViews() }
    private fun incPoison1() { poison1++; updateViews() }
    private fun decPoison1() { if (poison1 > 0) poison1--; updateViews() }

    // Player 2 operations
    private fun incLife2() { life2++; updateViews() }
    private fun decLife2() { if (life2 > 0) life2--; updateViews() }
    private fun incPoison2() { poison2++; updateViews() }
    private fun decPoison2() { if (poison2 > 0) poison2--; updateViews() }

    private fun updateViews() {
        with(binding) {
            counterP1.text = String.format("%d/%d", life1, poison1)
            counterP2.text = String.format("%d/%d", life2, poison2)
        }
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_reset, menu)
            }
            
            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId) {
                    R.id.reset -> {
                        resetGame()
                        true
                    }
                    else -> false
                }
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun resetGame() {
        life1 = 20; life2 = 20
        poison1 = 0; poison2 = 0
        updateViews()
        
        view?.let {
            Snackbar.make(it, "New Game!", Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.apply {
            putInt("life1", life1)
            putInt("life2", life2)
            
            putInt("poison1", poison1)
            putInt("poison2", poison2)
        }
    }
}