// This file has been migrated to Kotlin (FirstFragment.kt).
// Please delete this file.
//
// package com.example.practicavidas;
// ... (commented out to avoid duplicate class error)
